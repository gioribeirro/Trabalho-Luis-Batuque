/* Batuque — micro-animações extras (barra de rota, aparecer ao rolar, ripple). Respeita "reduzir movimento". */
(function () {
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var bar = document.getElementById("routeBar");

  /* 1. Barra fina no topo a cada troca de página */
  if (bar && !reduce) {
    window.addEventListener("hashchange", function () { bar.classList.remove("go"); void bar.offsetWidth; bar.classList.add("go"); });
    bar.addEventListener("animationend", function () { bar.classList.remove("go"); });
  }

  /* 2. Ripple nos botões */
  if (!reduce) {
    document.addEventListener("pointerdown", function (e) {
      var b = e.target.closest && e.target.closest(".btn");
      if (!b || b.disabled) return;
      var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 1.6, s = document.createElement("span");
      s.className = "ripple";
      s.style.cssText = "width:" + d + "px;height:" + d + "px;left:" + (e.clientX - r.left - d / 2) + "px;top:" + (e.clientY - r.top - d / 2) + "px";
      b.appendChild(s);
      s.addEventListener("animationend", function () { s.remove(); });
    });
  }

  /* 3. Cards abaixo da dobra aparecem suavemente quando entram na tela */
  var io = (!reduce && "IntersectionObserver" in window) ? new IntersectionObserver(function (list) {
    list.forEach(function (en) {
      if (!en.isIntersecting) return;
      var el = en.target; io.unobserve(el); el.classList.add("is-in");
      setTimeout(function () { el.classList.remove("reveal", "is-in"); }, 700);   // devolve o controle ao hover normal
    });
  }, { rootMargin: "0px 0px -40px 0px" }) : null;

  function scan(view) {
    if (!io || !view) return;
    var vh = window.innerHeight;
    view.querySelectorAll(".card:not(.stagger):not(.fade-swap):not(.hero)").forEach(function (el) {
      if (el.parentElement && el.parentElement.closest(".card")) return;          // só o card externo
      if (el.getBoundingClientRect().top < vh) return;                             // já visível: sem efeito
      el.classList.add("reveal"); io.observe(el);
    });
  }
  var main = document.getElementById("main");
  if (main && io) new MutationObserver(function () { scan(document.getElementById("view")); }).observe(main, { childList: true });
})();
