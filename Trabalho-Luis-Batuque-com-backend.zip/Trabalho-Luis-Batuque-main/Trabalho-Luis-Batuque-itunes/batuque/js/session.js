/* Batuque — sessão. Com o backend ligado: conta real (JWT). Sem ele: modo local simulado. NUNCA guarda senha no navegador. */
(function (B) {
  var st = B.store.state, c = null;
  var returnTo = null;

  /* Guarda o token; se a conta mudou neste navegador, limpa os dados locais da anterior */
  function adopt(r) {
    var prev = B.api.uid();
    B.api.setAuth(r.token, r.user.id);
    if (prev && String(prev) !== String(r.user.id)) { B.store.reset(); B.api.resetSynced(); }
  }
  function localSession(email) {
    var nome = st.session.nome || st.profile.nome;
    B.store.set("session", { logado: true, email: String(email || ""), nome: nome });
    B.ui.toast("Servidor offline: usando o modo local", "soft");
  }
  function applyRegister(nome, email) {
    B.store.set("session", { logado: true, email: String(email || ""), nome: String(nome || "") });
    var p = JSON.parse(JSON.stringify(st.profile));
    p.nome = nome; p.desde = new Date().getFullYear();
    B.store.set("profile", p);
    B.store.set("onboarded", false);
    if (!B.api.hasToken()) B.ui.toast("Servidor offline: conta criada só neste navegador", "soft");
  }

  var Session = {
    isLogged: function () { return !!st.session.logado; },
    /* Login/cadastro reais quando o servidor está ligado; se ele estiver offline, cai no modo local simulado.
       A senha vai só ao servidor (que guarda um hash) e nunca fica no navegador. */
    login: function (email, senha) {
      return B.api.request("POST", "/auth/login", { email: email, senha: senha }).then(function (r) {
        adopt(r);
        B.store.set("session", { logado: true, email: r.user.email, nome: r.user.nome });
        return B.sync.pull(true).then(function (changed) { return { changed: changed }; });   // dados da conta vencem os locais
      }, function (e) {
        if (!e.offline) throw e;
        localSession(email); return { offline: true };
      });
    },
    register: function (o) {
      return B.api.request("POST", "/auth/register", { nome: o.nome, email: o.email, senha: o.senha }).then(function (r) {
        adopt(r);
        applyRegister(r.user.nome, r.user.email);
        B.sync.schedule();
        return {};
      }, function (e) {
        if (!e.offline) throw e;
        applyRegister(o.nome, o.email); return { offline: true };
      });
    },
    logout: function () {
      B.api.clearToken();                                  // encerra a sessão no servidor (o token deixa de existir aqui)
      B.store.set("session", { logado: false, email: "", nome: st.session.nome });
      var dot = document.getElementById("syncDot"); if (dot) dot.dataset.sync = "guest";
      if (B.Player.playing) B.Player.audio.pause();
      B.ui.toast("Você saiu");
      location.hash = "#/login";
    },
    /* Guarda o retorno e manda para o login quando não há sessão */
    requireLogin: function (returnHash) {
      if (Session.isLogged()) return true;
      returnTo = returnHash || location.hash || "#/inicio";
      location.hash = "#/login";
      return false;
    },
    takeReturn: function () { var r = returnTo; returnTo = null; return r; }
  };
  B.Session = Session;

  /* ---------- Layout compartilhado das telas de conta ---------- */
  function E(s) { return B.c.esc(s); }
  var re = { email: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/ };

  B.auth = {
    re: re,
    shell: function (inner) {
      c = B.c;
      return '<div class="auth">' +
        '<section class="auth__left"><div class="auth__brand"><span class="logo__ring" aria-hidden="true"></span><span><b class="logo__name">BATUQUE.</b><span class="logo__sub">Music Journal</span></span></div>' +
        '<div class="auth__hero"><h2 class="auth__title">Sua música.<br>Sua história.</h2><p class="auth__sub">Um espaço para descobrir, organizar e registrar o que a música representa para você.</p></div>' +
        '<div class="auth__card"><span class="atile atile--lg" style="--c:var(--accent)"><b class="atile__ini">B</b><i class="atile__disc"></i><span class="atile__cap">BATUQUE</span></span>' +
        '<div><p class="eyebrow eyebrow--accent">Um arquivo feito de escutas</p><h3 class="auth__card-t">Álbuns, artistas e resenhas no mesmo lugar.</h3>' +
        '<p class="small muted">Crie coleções com contexto, acompanhe suas descobertas e guarde suas avaliações.</p><p class="tiny muted auth__cap">DESIGN LIMPO · MÚSICA EM PRIMEIRO PLANO</p></div></div></section>' +
        '<section class="auth__right"><div class="auth__form">' + inner + "</div></section></div>";
    },
    /* Campo de texto com rótulo em caixa alta e mensagem de erro associada */
    field: function (id, label, o) {
      o = o || {};
      return '<div class="field"><label class="field__label" for="' + id + '">' + E(label) + "</label>" +
        '<div class="field__box">' + (o.password
          ? '<input class="field__input" id="' + id + '" name="' + id + '" type="password" autocomplete="' + (o.ac || "current-password") + '" placeholder="' + E(o.ph || "") + '" aria-describedby="' + id + 'Err"><button type="button" class="field__eye" data-eye="' + id + '" aria-label="Mostrar senha" aria-pressed="false"><span class="eye-on">' + B.c.icon("eye") + '</span><span class="eye-off">' + B.c.icon("eyeoff") + "</span></button>"
          : '<input class="field__input" id="' + id + '" name="' + id + '" type="' + (o.type || "text") + '" autocomplete="' + (o.ac || "off") + '" placeholder="' + E(o.ph || "") + '"' + (o.max ? ' maxlength="' + o.max + '"' : "") + ' aria-describedby="' + id + 'Err">') +
        '</div><p class="field__err" id="' + id + 'Err" role="alert"></p></div>';
    },
    /* Liga olho de senha, Enter, foco inicial, validação e estado de carregamento.
       rules(values) -> { campo: "mensagem" }; onOk(values, done) roda após ~500 ms simulados. */
    bind: function (root, rules, onOk) {
      var form = root.querySelector("form"), btn = form.querySelector("[data-submit]"), busy = false;
      var first = form.querySelector("input"); if (first) setTimeout(function () { first.focus(); }, 60);
      form.addEventListener("click", function (e) {
        var eye = e.target.closest("[data-eye]"); if (!eye) return;
        var inp = form.querySelector("#" + eye.dataset.eye), show = inp.type === "password";
        inp.type = show ? "text" : "password";
        eye.setAttribute("aria-pressed", show); eye.setAttribute("aria-label", show ? "Ocultar senha" : "Mostrar senha");
        eye.classList.toggle("is-on", show);
      });
      function clearErr(inp) { inp.removeAttribute("aria-invalid"); var m = form.querySelector("#" + inp.id + "Err"); if (m) m.textContent = ""; inp.closest(".field").classList.remove("has-err"); }
      form.addEventListener("input", function (e) { if (e.target.matches("input")) clearErr(e.target); });
      function showErrs(errs) {
        var keys = Object.keys(errs).filter(function (k) { return form.querySelector("#" + k); });
        keys.forEach(function (k) {
          var inp = form.querySelector("#" + k); inp.setAttribute("aria-invalid", "true");
          inp.closest(".field").classList.add("has-err");
          form.querySelector("#" + k + "Err").textContent = errs[k];
        });
        form.classList.remove("shake"); void form.offsetWidth; form.classList.add("shake");
        if (keys.length) form.querySelector("#" + keys[0]).focus();
      }
      function finish(errs) {                       // chamado quando o envio termina (com ou sem erros do servidor)
        busy = false; btn.classList.remove("is-loading"); btn.disabled = false;
        if (errs && Object.keys(errs).length) showErrs(errs);
      }
      form.addEventListener("submit", function (e) {
        e.preventDefault(); if (busy) return;
        var v = {}; form.querySelectorAll("input").forEach(function (i) { v[i.id] = i.value; });
        var errs = rules(v);
        form.querySelectorAll("input").forEach(clearErr);
        if (Object.keys(errs).length) { showErrs(errs); return; }
        busy = true; btn.classList.add("is-loading"); btn.disabled = true;
        if (onOk.length >= 2) onOk(v, finish);      // onOk(valores, finish): quem chama avisa quando terminou
        else setTimeout(function () { finish(); onOk(v); }, 500);   // telas simuladas: ~500 ms
      });
    }
  };
})(window.Batuque);
